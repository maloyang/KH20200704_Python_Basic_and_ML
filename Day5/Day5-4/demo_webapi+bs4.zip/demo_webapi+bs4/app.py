# -*- coding: utf-8 -*-

import os
import random
import time
import requests

from flask import Flask, request, abort, render_template
from flask import json, jsonify
from flask_cors import CORS, cross_origin # for cross domain problem

import sqlite3
import time
import json

#app = Flask(__name__)
app = Flask(__name__, static_url_path='', static_folder='static')
CORS(app)

aqi_db = 'aqi_db.db'

@app.route('/')
def airbox():
    return app.send_static_file('index.html')

@app.route('/api/data/last', methods=['GET'])
def api_data_last():
    SiteName = request.args.get('SiteName') #ex: 左營
    if not SiteName:
        SiteName = '左營'
    # 開始下SQL資料取資料
    #SiteName = '左營'
    conn = sqlite3.connect(aqi_db)
    cursor = conn.cursor()
    res = cursor.execute("SELECT * FROM aqi WHERE SiteName = '%s' ORDER BY PublishTime DESC limit 1" %(SiteName) )
    rows = res.fetchall()

    data_list = list(rows)

    return jsonify(data_list[0])

@app.route('/api/data/history', methods=['GET'])
def api_data_rt_get():
    SiteName = request.args.get('SiteName') #ex: 左營
    if not SiteName:
        SiteName = '左營'

    # 取出最近的資料
    conn = sqlite3.connect(aqi_db)
    cursor = conn.cursor()
    res = cursor.execute("SELECT * FROM aqi WHERE SiteName = '%s' ORDER BY PublishTime DESC limit 12" %(SiteName) )
    rows = res.fetchall()

    data_list = list(rows)

    def take_time(elem):
        return elem[0]
    data_list.sort(key=take_time)

    return jsonify(data_list)


if __name__ == "__main__":
    app.run(debug=True, port=80)
